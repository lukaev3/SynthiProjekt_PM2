
% Beispielaufruf:
db_soll = [6  3  0  -2.5  -5  -7.5  -10  -12.5  -15  -17.5  -20  -22.5  -25  -27.5  -30]; % gewünschte Amplitude in dB
bit_resolution = 15;      % Bit-Auflösung

Ue = (2^14)-1;
Ua = Ue.*(10.^(db_soll./20));

binaryNumber = dec2bin(Ua);

